
package juegocarros;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class JuegoCarros extends Thread {

    private JLabel eti;
    private Carros posicion;
   
    public JuegoCarros ( JLabel eti , Carros posicion){
        this.eti=eti;
        this.posicion=posicion;
    }
    
   public void run(){
        int[] carros = new int[4];
        int[] ordenLlegada = new int[4];

        String[] nombres = {"Mario", "Bowser", "Peach", "Wario"};

        while(true){
            try{
                sleep((int)(Math.random()*300));

                carros[0] = posicion.getCarroNum1().getLocation().x;
                carros[1] = posicion.getCarroNum2().getLocation().x;
                carros[2] = posicion.getCarroNum3().getLocation().x;
                carros[3] = posicion.getCarroNum4().getLocation().x;

                boolean carreraFinalizada = true;
                for(int i=0; i<carros.length; i++){
                    if(carros[i] < posicion.getMeta().getLocation().x-20){
                        carreraFinalizada = false;
                        break;
                    }
                }

                if(!carreraFinalizada){
                    eti.setLocation(eti.getLocation().x+10,eti.getLocation().y);
                    posicion.repaint();
                } else {
                    break;
                }

            } catch(InterruptedException e){
                System.out.println("error de ejecucion");
            }
        }

        if(eti.getLocation().x >= posicion.getMeta().getLocation().x-10){

            for(int i=0; i<carros.length; i++){
                int count = 1;
                for(int j=0; j<carros.length; j++){
                    if(carros[i] > carros[j]){
                        count++;
                    }
                }
                ordenLlegada[i] = count;
            }
            
                

            StringBuilder mensaje = new StringBuilder();
            for(int i=1; i<=carros.length; i++){
                for(int j=0; j<carros.length; j++){
                    if(ordenLlegada[j] == i){
                        mensaje.append(i).append(": ").append(nombres[j]).append("\n");
                    }
                }
            }
            

            JOptionPane.showMessageDialog(null, mensaje.toString());
        }
    }

   
}
